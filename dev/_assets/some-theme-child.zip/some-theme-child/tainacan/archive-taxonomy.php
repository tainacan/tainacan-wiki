<?php get_header(); ?>					
	<?php tainacan_the_faceted_search(); ?>
<?php get_footer(); ?>
