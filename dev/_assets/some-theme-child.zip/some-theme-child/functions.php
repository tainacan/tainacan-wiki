<?php
/**
 * Some Theme Child functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package some-theme-child
 */

add_action( 'wp_enqueue_scripts', 'some_theme_child_parent_theme_enqueue_styles' );

/**
 * Enqueue scripts and styles.
 */
function some_theme_child_parent_theme_enqueue_styles() {
	wp_enqueue_style( 'some-theme-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'some-theme-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		array( 'some-theme-style' )
	);

}
